# Auto-Scaling Web App on AWS ☁️

This beginner-friendly project shows how to deploy a simple, highly available web application using AWS services.

## 🚀 Services Used
- Amazon EC2
- Launch Template
- Target Group
- Application Load Balancer
- Auto Scaling Group

## 🧠 What It Does
- Launches EC2 instances with Apache installed
- Distributes traffic with a Load Balancer
- Automatically scales based on CPU usage

## 📁 Files
- `user-data.sh`: Startup script for EC2 instances
- `README.md`: This documentation

## ✅ Status
Fully working and tested on AWS Free Tier

## 📸 Screenshots (optional)
Add screenshots of your AWS setup or output here.

